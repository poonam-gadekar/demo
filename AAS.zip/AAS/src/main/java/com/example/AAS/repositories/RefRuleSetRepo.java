package com.example.AAS.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AAS.Entity.RefRuleSet;

public interface RefRuleSetRepo extends JpaRepository<RefRuleSet, Long> {

}
