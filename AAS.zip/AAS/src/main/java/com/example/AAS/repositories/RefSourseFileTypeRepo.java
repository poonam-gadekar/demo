package com.example.AAS.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AAS.Entity.RefSourseFileType;

public interface RefSourseFileTypeRepo extends JpaRepository<RefSourseFileType, Long> {

}
