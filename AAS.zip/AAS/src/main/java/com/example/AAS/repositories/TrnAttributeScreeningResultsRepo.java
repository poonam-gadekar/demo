package com.example.AAS.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AAS.Entity.TrnAttributeScreeningResults;

public interface TrnAttributeScreeningResultsRepo extends JpaRepository<TrnAttributeScreeningResults, Integer> {

}
