package com.example.AAS.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AAS.Entity.TrnAttributeRuleSet;

public interface TrnAttrubuteRuleSetRepo extends JpaRepository<TrnAttributeRuleSet, Integer> {

}
