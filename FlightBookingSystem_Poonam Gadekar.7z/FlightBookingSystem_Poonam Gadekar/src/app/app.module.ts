import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserloginComponent } from './userlogin/userlogin.component';



import { BookflightComponent } from './components/usercomponents/bookflight/bookflight.component';
import { BookHistoryComponent } from './components/usercomponents/book-history/book-history.component';
import { ManageBookingsComponent } from './components/usercomponents/manage-bookings/manage-bookings.component';

import { UserdashboardComponent } from './components/usercomponents/userdashboard/userdashboard.component';
import { AdmindashboardComponent } from './components/admincomponents/admindashboard/admindashboard.component';
import { ManageschedulesComponent } from './components/admincomponents/manageschedules/manageschedules.component';
import { ManagediscountsComponent } from './components/admincomponents/managediscounts/managediscounts.component';
import { ManageairlinesComponent } from './components/admincomponents/manageairlines/manageairlines.component';
import { ReportsComponent } from './components/admincomponents/reports/reports.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {UserserviceService} from './services/userservice.service';
import{AdminserviceService} from './services/adminservice.service';
import { HttpClientModule } from '@angular/common/http';
import { AddairlineComponent } from './components/admincomponents/addairline/addairline.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    UserloginComponent,
   
  
   
    BookflightComponent,
    BookHistoryComponent,
    ManageBookingsComponent,
   
    UserdashboardComponent,
   
    AdmindashboardComponent,
   
    ManageschedulesComponent,
   
    ManagediscountsComponent,
   
    ManageairlinesComponent,
   
    ReportsComponent,
   
    AddairlineComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    NgbModule,
    HttpClientModule

  ],
  providers: [UserserviceService,AdminserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
