import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import {AdminserviceService} from '../../../services/adminservice.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-addairline',
  templateUrl: './addairline.component.html',
  styleUrls: ['./addairline.component.css']
})
export class AddairlineComponent implements OnInit {
  airlineformdata;
  constructor(private _adminservice : AdminserviceService,private router: Router ) { }

  ngOnInit(): void {

    this.airlineformdata = new FormGroup({
      airlineName: new FormControl(""),
      contactNumber: new FormControl(""),
      address: new FormControl("")
    })


}

addAirLine(data){
console.log("airline data display" + data)
//postAirLines(data)  
this._adminservice.postAirLines(data).subscribe((data: any[])=>{
  console.log(data);
  
})  ;  
this.router.navigate(['admin/manageairlines'])
}






}
