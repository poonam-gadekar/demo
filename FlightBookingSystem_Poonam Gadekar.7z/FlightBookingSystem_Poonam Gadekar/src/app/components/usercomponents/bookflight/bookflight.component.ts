import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { Router} from '@angular/router';
import {UserserviceService} from '../../../services/userservice.service'
import {AdminserviceService} from '../../../services/adminservice.service'

import {NgbDateStruct, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-bookflight',
  templateUrl: './bookflight.component.html',
  styleUrls: ['./bookflight.component.css']
})
export class BookflightComponent implements OnInit {
  
  formdata;
  userData;
 public cities=[];
 public flights : any;
  isSearch = true;
  tripDisplay =false;
  bookFlight = false;
  isBook= false;
  from:any;
  to:any;
  fromDate:any;
  returnDate:any;
  flightData:flightInfo;
 userdata: any;
  constructor(private router: Router,private calendar: NgbCalendar,
    private _userservice :UserserviceService,private _adminservice : AdminserviceService ) { }
  

  ngOnInit(): void {
    
    this._adminservice.getcities().subscribe((data: any[])=>{
      console.log(data);
      this.cities = data;
    })  ;
    this.flights= this._adminservice.getFlights();
    this.formdata = new FormGroup({
      from: new FormControl(""),
      to: new FormControl(""),
      fromDate: new FormControl(""),
      returnDate: new FormControl("")
  });
  this.userData=new FormGroup({
firstName: new FormControl(""),
lastName: new FormControl(""),
email: new FormControl(""),
seatnumber: new FormControl("")
  })

  }
  onClickSubmit(data) {
    console.log(data)
  
    this.from= data.from;
    
    this.to=data.to;
    this.fromDate=data.fromDate;
    this.returnDate=data.returnDate;
   this.isSearch = false;
    this.tripDisplay =true;
 }
 onClickPrevious(){
  this.isSearch = true;
    this.tripDisplay =false;
}
bookflight(data){
this.userdata={
  firstName: data.firstName,
  lastName:data.lastName,
  emmail: data.emmail,
  seatnumber:data.seatnumber,
  flightDetails: this.flightData
}
this._userservice.bookFlight(this.userdata).subscribe((data: any[])=>{
  console.log(data);
  
})  ;

localStorage.setItem('bookedData',JSON.stringify(this.userdata))
alert("You Flight Book Successful");
this.bookFlight = false;
this.isSearch = true;
  this.tripDisplay =false;

}

slectflight(flight){
console.log("fDat"+flight);
this.flightData=flight;
  this.bookFlight = true;
  this.isSearch = false;
    this.tripDisplay =false;
}

}



interface flightInfo{
  "flightNumber" : number,
  "airline" : string,
  "fromPlace" : string,
  "toPlace" : string,
 "startDateTime" : string,
 "endDateTime": string,
 "price": string
}

interface userInfo {
  firstName: string,
  lastName:String,
  emmail: string,
  contactNo:string
  flightDetails:flightInfo
}