import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {
  private REST_API_SERVER = "http://localhost:3000";
  constructor(private httpClient: HttpClient) { }

  getcities(){
   // return [{"cityId": 1,"cityName": "Pune"},{"cityId": 2,"cityName": "Mumbai"}];
   return this.httpClient.get(this.REST_API_SERVER+ "/cities");

  }
  postAirLines(data){
    return this.httpClient.post(this.REST_API_SERVER+ "/airlines",data);
  }
  getAirlines(){
    return this.httpClient.get(this.REST_API_SERVER+ "/airlines");

  }
  deleteAirlines(id){
    return this.httpClient.delete(this.REST_API_SERVER+ "/airlines/" +id);

  }
  

  getFlights(){
return [ {"flightNumber" : 456,
"airline" :"KingFisher",
"fromPlace" :"pune",
"toPlace" :"mumbai",
"startDateTime" :"2020-04-17 17:19",
"endDateTime": "2020-04-18 05:19",
"price": "2000"
},
  {
  "flightNumber" : 456,
    "airline" :"Jet",
    "fromPlace" :"pune",
    "toPlace" :"mumbai",
   "startDateTime" :"2020-04-17 17:19",
   "endDateTime": "2020-04-18 17:19",
   "price": "1000"
  },
  {
    "flightNumber" : 456,
    "airline" :"Indigo",
    "fromPlace" :"pune",
    "toPlace" :"mumbai",
   "startDateTime" :"2020-04-18 17:19",
   "endDateTime": "2020-04-18 17:19",
   "price": "5000"
  
  }];

  }
}
