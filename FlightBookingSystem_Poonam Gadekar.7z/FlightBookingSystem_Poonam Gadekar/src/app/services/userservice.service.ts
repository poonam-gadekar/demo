import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

 bookedFlights:any;
 private REST_API_SERVER = "http://localhost:3000";

  constructor(private httpClient: HttpClient) {
    this.bookedFlights=[]
   }

  bookFlight(data){
    return this.httpClient.post(this.REST_API_SERVER+ "/bookedFligts",data);

    //this.bookedFlights.push(data);
    //console.log("booked filghts...................."+ this.bookedFlights)
  }

  getbookedFlights(){
    return this.httpClient.get(this.REST_API_SERVER+ "/bookedFligts");
  }
  deleteflight(id){
    return this.httpClient.delete(this.REST_API_SERVER+ "/bookedFligts/"+id);
  }

}
