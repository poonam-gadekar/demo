import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AppComponent} from './app.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserdashboardComponent } from './components/usercomponents/userdashboard/userdashboard.component';
import { BookflightComponent } from './components/usercomponents/bookflight/bookflight.component';
import { BookHistoryComponent } from './components/usercomponents/book-history/book-history.component';
import { ManageBookingsComponent } from './components/usercomponents/manage-bookings/manage-bookings.component';
import {AdmindashboardComponent} from './components/admincomponents/admindashboard/admindashboard.component';
import {ManageschedulesComponent} from './components/admincomponents/manageschedules/manageschedules.component';
import {ManagediscountsComponent} from './components/admincomponents/managediscounts/managediscounts.component';
import{AddairlineComponent} from './components/admincomponents/addairline/addairline.component';
import {ManageairlinesComponent} from './components/admincomponents/manageairlines/manageairlines.component';
import {ReportsComponent} from './components/admincomponents/reports/reports.component';




const routes: Routes = [{
  path: 'login',
  component: UserloginComponent
},

{
  path: '',
  component: AppComponent
},
{
  
  path: 'admin',
  component: AdmindashboardComponent,
  children: [
    {
      path: 'manageschedules',
      component: ManageschedulesComponent
    },
    {
      path: 'managediscounts',
      component: ManagediscountsComponent
    },
    {
      path: 'manageairlines',
      component: ManageairlinesComponent
    },
    {
      path: 'reports',
      component: ReportsComponent
    },
    {
      path: 'addairline',
      component: AddairlineComponent
    }
    
  ],
},



{
  path: 'app-userdashboard',
  component: UserdashboardComponent,
  children: [
    {
      path: 'bookflight',
      component: BookflightComponent
    },
    {
      path: 'managebooking',
      component: ManageBookingsComponent
    },
    {
      path: 'bookinghistory',
      component: BookHistoryComponent
    }
    
    
  ],
},



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
