import { Component, OnInit } from '@angular/core';
import {AdminserviceService} from '../../../services/adminservice.service'

@Component({
  selector: 'app-manageairlines',
  templateUrl: './manageairlines.component.html',
  styleUrls: ['./manageairlines.component.css']
})
export class ManageairlinesComponent implements OnInit {
  airlines : any

  constructor(private _adminservice : AdminserviceService) { }

  ngOnInit(): void {

    this._adminservice.getAirlines().subscribe((data: any[])=>{
      console.log(data);
      this.airlines = data;
    })  ;
  }

  deleteairline(id){
    console.log("booked is" +id)
    this._adminservice.deleteAirlines(id).subscribe((data: any[])=>{
      console.log(data);
     
    })  ;

  }

}
