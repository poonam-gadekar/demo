import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageschedules',
  templateUrl: './manageschedules.component.html',
  styleUrls: ['./manageschedules.component.css']
})
export class ManageschedulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
