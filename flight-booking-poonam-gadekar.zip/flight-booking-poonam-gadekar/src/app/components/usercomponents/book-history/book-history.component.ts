import { Component, OnInit } from '@angular/core';
import {UserserviceService} from '../../../services/userservice.service'


@Component({
  selector: 'app-book-history',
  templateUrl: './book-history.component.html',
  styleUrls: ['./book-history.component.css']
})
export class BookHistoryComponent implements OnInit {
  flights :any;
 

  constructor(private _userservice :UserserviceService) {
    this.flights=[]
   }

  ngOnInit(): void {
    this._userservice.getbookedFlights().subscribe((data: any[])=>{
      console.log(data);
      this.flights = data;
  })  ;

  }
}
