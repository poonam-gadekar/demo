import { Component, OnInit } from '@angular/core';
import {UserserviceService} from '../../../services/userservice.service'

@Component({
  selector: 'app-manage-bookings',
  templateUrl: './manage-bookings.component.html',
  styleUrls: ['./manage-bookings.component.css']
})
export class ManageBookingsComponent implements OnInit {
flights :any;
data= localStorage.getItem('bookedData')
  constructor(private _userservice :UserserviceService) {
    this.flights=[]
   }

  ngOnInit(): void {
   // this.flights.push(JSON.parse(this.data))
   // console.log('data'+ this.flights)
   // getbookedFlights(id)
   this._userservice.getbookedFlights().subscribe((data: any[])=>{
    console.log(data);
    this.flights = data;
    
  })  ;
  

  }
  cancelflight(id){
console.log("booked is" +id)

this._userservice.deleteflight(id).subscribe((data: any[])=>{
  console.log(data);
 // this.flights = data;
  
})  ;

  }



}
